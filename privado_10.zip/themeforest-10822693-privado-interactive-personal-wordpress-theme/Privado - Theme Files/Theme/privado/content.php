<?php
/**
 * @package Privado
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <div class="single-blog-meta">
                <time><i class="fa fa-clock-o fa-fw"></i><?php the_time( get_option( 'date_format' ) ); ?></time>
                <span class="tags"><i class="fa fa-tags fa-fw"></i> 
                    <?php
                        $categories = get_the_category();
                        $separator = ', ';
                        $output = '';
                        if($categories){
                            foreach($categories as $category) {
                                $output .= '<a href="'.get_category_link( $category->term_id ).'" title="' . esc_attr( sprintf( __( 'View all posts in %s', 'privado'), $category->name ) ) . '">'.$category->cat_name.'</a>'.$separator;
                            }
                        echo trim($output, $separator);
                        }
                        ?>
                </span>
            </div>
            <h1 class="blog-title"><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h1>
            <div class="post-content">
               <?php
                    $content = get_the_content();
                    $trimmed_content = strip_shortcodes(strip_tags(wp_trim_words( $content, 60)));
                    echo $trimmed_content;
                ?>
            </div>
            <a href="<?php the_permalink() ?>" class="btn btn-read-more">Continue Reading</a>

</article><!-- #post-## -->