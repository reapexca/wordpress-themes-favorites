<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package Privado
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>

<aside>
    <div class="col-md-4 col-md-pull-8 widget-container">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside> <!-- Sidebar end-->

<?php get_template_part("templates/sections/footer");?>
</main> <!-- main blog container end-->