<?php
global $codetic_privado;
/**
 * The template for displaying archive pages.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package Privado
 */
$blog_url = $codetic_privado['privado_blog_url'];
get_header(); ?>

<main class="blog-container">
	<header class="single-page-header">
		<div class="header-inner">
			<div class="header-content">
			<a href="<?php echo esc_url($blog_url);?>" class="btn back-to-home"><i class="fa fa-arrow-left fa-fw"></i>Back to Blog</a>
				<?php
					the_archive_title( '<h1 class="blog-title container">', '</h1>' );
					the_archive_description( '<div class="taxonomy-description">', '</div>' );
				?>
			</div>
		</div>
	</header><!-- .page-header -->

	<section id="blog-list">

	    <div class="col-md-8 col-md-push-4 blog-list-container">

			<?php if ( have_posts() ) : ?>

				<?php /* Start the Loop */ ?>
				<?php while ( have_posts() ) : the_post(); ?>

					<?php
						/* Include the Post-Format-specific template for the content.
						 * If you want to override this in a child theme, then include a file
						 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
						 */
						get_template_part( 'content', get_post_format() );
					?>

				<?php endwhile; ?>


			<?php else : ?>

				<?php get_template_part( 'content', 'none' ); ?>

			<?php endif; ?>
			
			<?php get_template_part( 'content', 'pagination' ); ?>

	    </div><!-- Blog List container end -->
	</section>
	 <!-- #Blog List end-->

<?php get_sidebar(); ?>
</main>
<?php get_footer(); ?>
