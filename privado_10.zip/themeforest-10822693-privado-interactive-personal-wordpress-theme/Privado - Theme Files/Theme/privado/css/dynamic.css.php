<?php
  header("Content-type: text/css; charset: UTF-8");

  global $codetic_privado;
/**
 * Dynamic CSS for Privado
 *
 * @package Privado
 */
?>

/* Body Background Color */

body {
	background: <?php echo $codetic_privado['privado_body_bg']; ?>;
}

/* Preloader Styles */

#preloader{
  background-color:<?php echo $codetic_privado['privado_preloader_bg']; ?>; 
}

.loader {
  background: url("<?php echo $codetic_privado['privado_preloader_image']['url']; ?>") no-repeat scroll center center / cover rgba(0, 0, 0, 0);
}


/* Page Background images */

.page-container .single-page:first-of-type::after {
  background-image: url("<?php echo $codetic_privado['privado_profile_section_image']['url']; ?>");
}

.page-container .single-page:nth-of-type(2)::after {
  background-image: url("<?php echo $codetic_privado['privado_resume_section_image']['url']; ?>");
}

.page-container .single-page:nth-of-type(3)::after {
  background-image: url("<?php echo $codetic_privado['privado_portfolio_section_image']['url']; ?>");
}

.page-container .single-page:nth-of-type(4)::after{
  background-image: url("<?php echo $codetic_privado['privado_contact_section_image']['url']; ?>");
}

/* Page overlay colors */ 

.single-page:nth-child(1) {
  background-color: <?php echo $codetic_privado['privado_profile_section_overlay']; ?>;
}

.single-page:nth-child(2) {
  background-color: <?php echo $codetic_privado['privado_resume_section_overlay']; ?>;
}

.single-page:nth-child(3) {
  background-color:  <?php echo $codetic_privado['privado_portfolio_section_overlay']; ?>;
}

.single-page:nth-child(4) {
  background-color: <?php echo $codetic_privado['privado_contact_section_overlay']; ?>;
}


/* Theme Custom CSS */ 


<?php
	if (isset($codetic_privado['privado_custom_css'])) echo $codetic_privado['privado_custom_css'];
?>
