<?php

add_filter( 'cmb2_meta_boxes', 'privado_employment_metaboxes' );

function privado_employment_metaboxes(array $meta_boxes){
    $prefix = '_privado_';

    $meta_boxes['employment_metabox'] = array(
        'id'            => 'employment_metabox',
        'title'         => __( 'Employment Options', 'privado' ),
        'object_types'  => array( 'employment', ), // Post type
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true, // Show field names on the left
        'fields'        => array(
            array(
                'name' => __('Company: ',"privado"),
                'id' => $prefix . 'employment_company',
                'type' => 'text_medium'
            ),
            array(
                'name' => __('Designation: ',"privado"),
                'id' => $prefix . 'employment_designation',
                'type' => 'text_medium',
                'description' => 'i.e. Lead Developer'
            ),
            array(
                'name' => __('Time (From - To): ',"privado"),
                'id' => $prefix . 'employment_time',
                'type' => 'text_medium',
                'description' => 'i.e. 20012 - Present'
            ),
            array(
                'name' => __('Description: ',"privado"),
                'id' => $prefix . 'employment_description',
                'type' => 'wysiwyg',
                'options'=>array(
                    "textarea_rows"=>10
                )
            ),
        ),
    );

    return $meta_boxes;
}
