<?php

add_filter( 'cmb2_meta_boxes', 'privado_education_metaboxes' );

function privado_education_metaboxes(array $meta_boxes){
    $prefix = '_privado_';

    $meta_boxes['education_metabox'] = array(
        'id'            => 'education_metabox',
        'title'         => __( 'Education Options', 'privado' ),
        'object_types'  => array( 'education', ), // Post type
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true, // Show field names on the left
        'fields'        => array(
            array(
                'name' => __('College: ',"privado"),
                'id' => $prefix . 'edu_college',
                'type' => 'text_medium'
            ),
            array(
                'name' => __('Degree Earned: ',"privado"),
                'id' => $prefix . 'edu_degree',
                'type' => 'text_medium',
                'description' => 'i.e. Bachelor of Science'
            ),
            array(
                'name' => __('Time (From - To): ',"privado"),
                'id' => $prefix . 'edu_time',
                'type' => 'text_medium',
                'description' => 'i.e. 2008 - 2011'
            ),
            array(
                'name' => __('Description: ',"privado"),
                'id' => $prefix . 'edu_description',
                'type' => 'wysiwyg',
                'options'=>array(
                    "textarea_rows"=>10
                )
            ),
        ),
    );

    return $meta_boxes;
}
