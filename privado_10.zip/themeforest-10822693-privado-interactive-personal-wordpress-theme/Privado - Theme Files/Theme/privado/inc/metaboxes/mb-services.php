<?php

add_filter( 'cmb2_meta_boxes', 'privado_service_metaboxes' );

function privado_service_metaboxes(array $meta_boxes){
    $prefix = '_privado_';

    $meta_boxes['service_metabox'] = array(
        'id'            => 'service_metabox',
        'title'         => __( 'Service Options', 'privado' ),
        'object_types'  => array( 'service', ), // Post type
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true, // Show field names on the left
        'fields'        => array(
            array(
                'name'    => 'Service Title',
                'id'      => $prefix . 'service_title',
                'type'    => 'text_medium'
            ),
            array(
                'name'    => 'Service Icon',
                'description' => 'Font Awesome Icon class',
                'default' => 'fa-lightbulb-o',
                'id'      => $prefix . 'service_icon',
                'type'    => 'text_medium'
            ),
            array(
                'name' => __( 'Service Description', 'privado' ),
                'id'   => $prefix . 'service_description',
                'type' => 'wysiwyg',
                'options'=>array(
                    "textarea_rows"=>10
                )
            ),
        ),
    );

    return $meta_boxes;
}
