<?php

add_filter( 'cmb2_meta_boxes', 'privado_recognition_metaboxes' );

function privado_recognition_metaboxes(array $meta_boxes){
    $prefix = '_privado_';

    $meta_boxes['recognition_metabox'] = array(
        'id'            => 'recognition_metabox',
        'title'         => __( 'Recognition Options', 'privado' ),
        'object_types'  => array( 'recognition', ), // Post type
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true, // Show field names on the left
        'fields'        => array(
            array(
                'name'    => 'Recognition Title',
                'id'      => $prefix . 'recognition_title',
                'type'    => 'text_medium',
                'description' => 'i.e. App Development Contest'
            ),
            array(
                'name'    => 'Recognition Subtiitle',
                'id'      => $prefix . 'recognition_subtitle',
                'type'    => 'text_medium',
                'description' => 'i.e. Winner'
            ),
            array(
                'name'    => 'Recognition Icon',
                'description' => 'Font Awesome Icon class (i.e. fa-trophy)',
                'default' => 'fa-trophy',
                'id'      => $prefix . 'recognition_icon',
                'type'    => 'text_medium'
            ),
            array(
                'name'    => 'Place',
                'id'      => $prefix . 'recognition_place',
                'type'    => 'text_medium',
                'description' => 'i.e. San Francisco, USA'
            ),
        ),
    );

    return $meta_boxes;
}
