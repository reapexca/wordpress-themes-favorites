<?php

$sections[] = array(
    'title' => __('Portfolio Settings', 'privado'),
    'icon' => 'el-icon-briefcase',
    // 'submenu' => false, // Setting submenu to false on a given section will hide it from the WordPress sidebar menu!
    'fields' => array(

        array(
            'id' => 'privado_portfolio_section_display',
            'type' => 'switch',
            'title' => __('Display Portfolio', 'privado'),
            'default' => '1',
        ),

        array(
            'id' => 'privado_testimonials_section_display',
            'type' => 'switch',
            'title' => __('Display Testimonials', 'privado'),
            'default' => '1',
        ),

        array(
            'id' => 'privado_portfolio_facts_display',
            'type' => 'switch',
            'title' => __('Display Fun Facts', 'privado'),
            'default' => '1',
        ),


        array(
            'id' => 'privado_portfolio_page_title',
            'type' => 'text',
            'title' => __('Portfolio Page Title', 'privado'),
            'default' => 'Portfolio',
        ),

        array(
            'id' => 'privado_portfolio_page_icon',
            'type' => 'text',
            'title' => __('Portfolio Page Icon', 'privado'),
            'default' => "fa-briefcase",
            'description' => "Font Awesome icon class for Portfolio",
        ),
        array(
            'id' => 'privado_portfolio_page_subtitle',
            'type' => 'text',
            'title' => __('Portfolio Page Subtitle', 'privado'),
            'default' => 'Some of My Works...',
        ),
        array(
            'id'       => 'privado_portfolio_section_image',
            'type'     => 'media',
            'url'      => true,
            'title'    => __('Portfolio Page Background Image', 'privado'),
            'default'  => array(
                'url'=>get_template_directory_uri()."/img/img-3-large.jpg"
            ),

        ),

        array(
            'id'       => 'privado_portfolio_section_overlay',
            'type'     => 'color',
            'title'    => __('Portfolio Section overlay Color', 'privado'),
            'default'  => '#273336',
            'validate' => 'color',
            'transparent' => false,
        ),


        array(
            'id'        => 'portfolio_number',
            'type'      => 'slider',
            'title'     => __('Max Portfolio Appear', 'privado'),
            'desc'      => __('Min: 3, max: 60, step: 3, default value: 3', 'privado'),
            "default"   => 3,
            "min"       => 3,
            "step"      => 3,
            "max"       => 60,
            'display_value' => 'Max Post',
        ),

        array(
            'id'       => 'portfolio_post_order',
            'type'     => 'select',
            'title'    => __('Display Order Type', 'privado'), 
            'desc'     => __('Display Portfolio in Ascending or Descending Order', 'privado'),
            'options'  => array(
                '1' => 'Ascending Order',
                '2' => 'Descending Order',
            ),
            'default'  => '2',
        ),

        // Testimonial Section
        array(
           'id' => 'section-testimonial-post',
           'type' => 'section',
           'title' => __('Testimonial Section Settings', 'privado'),
           'indent' => true 
        ),

        array(
            'id' => 'privado_testimonial_title',
            'type' => 'text',
            'title' => __('Testimonial Title', 'privado'),
            'default' => 'Some of my happy clients',
        ),

        array(
            'id'       => 'privado_testimonial_icon',
            'type'     => 'media',
            'url'      => true,
            'title'    => __('Testimonial Icon', 'privado'),
            'default'  => array(
                'url'=>get_template_directory_uri()."/img/icons/smile.svg"
            ),
        ),

        array(
            'id'        => 'testimonial_number',
            'type'      => 'slider',
            'title'     => __('Max Testimonial Appear', 'privado'),
            'desc'      => __('Min: 1, max: 50, step: 1, default value: 3', 'privado'),
            "default"   => 3,
            "min"       => 1,
            "step"      => 1,
            "max"       => 50,
            'display_value' => 'Max Post',
        ),

        array(
            'id'       => 'testimonial_post_order',
            'type'     => 'select',
            'title'    => __('Display Order Type', 'privado'), 
            'desc'     => __('Display Testimonials in Ascending or Descending Order', 'privado'),
            'options'  => array(
                '1' => 'Ascending Order',
                '2' => 'Descending Order',
            ),
            'default'  => '2',
        ),
    )
);
