<?php

$sections[] = array(
    'title' => __('Blog Settings', 'privado'),
    'icon' => ' el-icon-pencil',
    // 'submenu' => false, // Setting submenu to false on a given section will hide it from the WordPress sidebar menu!
    'fields' => array(

        array(
            'id' => 'privado_blog_page_title',
            'type' => 'text',
            'title' => __('Blog Page Title', 'privado'),
            'default' => 'My Minimal Blog',
        ),

        array(
            'id' => 'privado_blog_page_icon',
            'type' => 'text',
            'title' => __('Blog Page Icon', 'privado'),
            'default' => "fa-pencil",
            'description' => "Font Awesome icon class for Blog",
        ),
        array(
            'id' => 'privado_blog_page_subtitle',
            'type' => 'text',
            'title' => __('Blog Page Subtitle', 'privado'),
            'default' => 'What I Think, I write here...',
        ),
        array(
            'id'       => 'privado_blog_bg_image',
            'type'     => 'media',
            'url'      => true,
            'title'    => __('Blog Background Image', 'privado'),
            'default'  => array(
                'url'=>get_template_directory_uri()."/img/blog-bg.jpg"
            ),

        ),
    )
);
