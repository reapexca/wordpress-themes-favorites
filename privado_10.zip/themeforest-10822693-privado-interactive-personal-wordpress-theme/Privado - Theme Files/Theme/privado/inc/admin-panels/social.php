<?php

$sections[] = array(
    'title' => __('Social & Footer', 'privado'),
    'icon' => 'el-icon-share',
    // 'submenu' => false, // Setting submenu to false on a given section will hide it from the WordPress sidebar menu!
    'fields' => array(

        array(
            'id' => 'privado_social_facebook',
            'type' => 'text',
            'title' => __('Facebook', 'privado'),
            'description' => 'Provide full profile link. Leave empty to hide',
            'default' => "https://www.facebook.com/Codetic",
        ),
        array(
            'id' => 'privado_social_twitter',
            'type' => 'text',
            'title' => __('Twitter', 'privado'),
            'description' => 'Provide full profile link. Leave empty to hide',
            'default' => "https://twitter.com/Codetic_Dev",
        ),
        array(
            'id' => 'privado_social_gplus',
            'type' => 'text',
            'title' => __('Google Plus', 'privado'),
            'description' => 'Provide full profile link. Leave empty to hide',
            'default' => "#",
        ),
        array(
            'id' => 'privado_social_linkedin',
            'type' => 'text',
            'title' => __('LinkedIn', 'privado'),
            'description' => 'Provide full profile link. Leave empty to hide',
            'default' => "#",
        ),
        array(
            'id' => 'privado_social_github',
            'type' => 'text',
            'title' => __('Github', 'privado'),
            'description' => 'Provide full profile link. Leave empty to hide',
            'default' => "#",
        ),
        array(
            'id' => 'privado_social_dribbble',
            'type' => 'text',
            'title' => __('Dribbble', 'privado'),
            'description' => 'Provide full profile link. Leave empty to hide',
            'default' => "#",
        ),
        array(
            'id' => 'privado_social_slideshare',
            'type' => 'text',
            'title' => __('Slideshare', 'privado'),
            'description' => 'Provide full profile link. Leave empty to hide',
        ),
        array(
            'id' => 'privado_social_instagram',
            'type' => 'text',
            'title' => __('Instagram', 'privado'),
            'description' => 'Provide full profile link. Leave empty to hide',
        ),
        array(
            'id' => 'privado_social_skype',
            'type' => 'text',
            'title' => __('Skype', 'privado'),
            'description' => 'Provide Skype username. Leave empty to hide',
            'default' => 're_enter_rupok',
        ),

         array(
            'id' => 'privado_footer',
            'type' => 'editor',
            'title' => __('Footer Copyright Text', 'privado'),
            'default' => '<a href="http://www.rupok.me">Nazmul H. Rupok</a> Copyright &copy; 2014 All right reserved',
        ),

    )
);
