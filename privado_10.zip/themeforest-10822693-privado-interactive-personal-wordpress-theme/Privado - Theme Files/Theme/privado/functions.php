<?php
/**
 * Privado functions and definitions
 *
 * @package Privado
 */

/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) ) {
	$content_width = 640; /* pixels */
}

/**
 * Initialize TGM Plugin Activation
 */

require_once dirname( __FILE__ ) . '/class-tgm-plugin-activation.php';
/**
 * Initialize CMB2
 */


// Initialize the metabox class

	if ( file_exists(  __DIR__ . '/libs/cmb/init.php' ) ) {
	  require_once  __DIR__ . '/libs/cmb/init.php';
	} 

/**
 * Initialize Redux
 */

if ( !class_exists( 'ReduxFramework' ) && file_exists( dirname( __FILE__ ) . '/libs/redux-framework/ReduxCore/framework.php' ) ) {
    require_once( dirname( __FILE__ ) . '/libs/redux-framework/ReduxCore/framework.php' );
    require_once(dirname(__FILE__) . '/inc/admin.php');
}


if ( ! function_exists( 'privado_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function privado_setup() {

	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on Privado, use a find and replace
	 * to change 'privado' to the name of your theme in all the template files
	 */
	load_theme_textdomain( 'privado', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );

    if (function_exists('add_theme_support')) {
        add_theme_support('post-thumbnails');
        add_image_size( 'portfolio-thumb', 480, 360, true );
        add_image_size( 'portfolio-preview', 650, 350, true );
    }

	// Custom Excerpt length

	function custom_excerpt_length( $length ) {
		return 15;
	}
	add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );

	// Custom Excerpt More
	function new_excerpt_more( $more ) {
		return ' ...';
	}
	add_filter('excerpt_more', 'new_excerpt_more');
	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'privado' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption',
	) );

	/*
	 * Enable support for Post Formats.
	 * See http://codex.wordpress.org/Post_Formats
	 */
	add_theme_support( 'post-formats', array(
		'aside', 'image', 'video', 'quote', 'link',
	) );

	// Set up the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'privado_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
	) ) );
}
endif; // privado_setup
add_action( 'after_setup_theme', 'privado_setup' );



// TGM Plugin Activation

add_action( 'tgmpa_register', 'privado_register_required_plugins' );

function privado_register_required_plugins() {

    /**
     * Array of plugin arrays. Required keys are name, slug and required.
     * If the source is NOT from the .org repo, then source is also required.
     */
    $plugins = array(

        array(
            'name'                  => 'Privado Custom Posts & Shortcodes', // The plugin name
            'slug'                  => 'privado-cpts', // The plugin slug (typically the folder name)
            'source'                => get_template_directory_uri() . '/plugins/privado-cpts.zip', // The plugin source
            'required'              => true, // If false, the plugin is only 'recommended' instead of required
            'version'               => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
            'force_activation'      => true, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
            'force_deactivation'    => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
            'external_url'          => '', // If set, overrides default API URL and points to an external URL
        ),

        array(
            'name'                  => 'Contact Form 7', // The plugin name
            'slug'                  => 'contact-form-7', // The plugin slug (typically the folder name)
            'source'                => get_template_directory_uri() . '/plugins/contact-form-7.zip', // The plugin source
            'required'              => false, // If false, the plugin is only 'recommended' instead of required
            'version'               => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
            'force_activation'      => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
            'force_deactivation'    => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
            'external_url'          => '', // If set, overrides default API URL and points to an external URL
        ),

    );

    // Change this to your theme text domain, used for internationalising strings
    $theme_text_domain = 'privado';

    $config = array(
        'id'                => 'privado-tgmpa',
        'domain'            => $theme_text_domain,           // Text domain - likely want to be the same as your theme.
        'default_path'      => '',                           // Default absolute path to pre-packaged plugins
        'parent_menu_slug'  => 'themes.php',         // Default parent menu slug
        'parent_url_slug'   => 'themes.php',         // Default parent URL slug
        'menu'              => 'install-required-plugins',   // Menu slug
        'has_notices'       => true,                         // Show admin notices or not
        'is_automatic'      => false,            // Automatically activate plugins after installation or not
        'message'           => '',               // Message to output right before the plugins table
        'strings'           => array(
            'page_title'                                => __( 'Install Required Plugins', $theme_text_domain ),
            'menu_title'                                => __( 'Install Plugins', $theme_text_domain ),
            'installing'                                => __( 'Installing Plugin: %s', $theme_text_domain ), // %1$s = plugin name
            'oops'                                      => __( 'Something went wrong with the plugin API.', $theme_text_domain ),
            'notice_can_install_required'               => _n_noop( 'This theme requires the following plugin: %1$s.', 'This theme requires the following plugins: %1$s.' ), // %1$s = plugin name(s)
            'notice_can_install_recommended'            => _n_noop( 'This theme recommends the following plugin: %1$s.', 'This theme recommends the following plugins: %1$s.' ), // %1$s = plugin name(s)
            'notice_cannot_install'                     => _n_noop( 'Sorry, but you do not have the correct permissions to install the %s plugin. Contact the administrator of this site for help on getting the plugin installed.', 'Sorry, but you do not have the correct permissions to install the %s plugins. Contact the administrator of this site for help on getting the plugins installed.' ), // %1$s = plugin name(s)
            'notice_can_activate_required'              => _n_noop( 'The following required plugin is currently inactive: %1$s.', 'The following required plugins are currently inactive: %1$s.' ), // %1$s = plugin name(s)
            'notice_can_activate_recommended'           => _n_noop( 'The following recommended plugin is currently inactive: %1$s.', 'The following recommended plugins are currently inactive: %1$s.' ), // %1$s = plugin name(s)
            'notice_cannot_activate'                    => _n_noop( 'Sorry, but you do not have the correct permissions to activate the %s plugin. Contact the administrator of this site for help on getting the plugin activated.', 'Sorry, but you do not have the correct permissions to activate the %s plugins. Contact the administrator of this site for help on getting the plugins activated.' ), // %1$s = plugin name(s)
            'notice_ask_to_update'                      => _n_noop( 'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.', 'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.' ), // %1$s = plugin name(s)
            'notice_cannot_update'                      => _n_noop( 'Sorry, but you do not have the correct permissions to update the %s plugin. Contact the administrator of this site for help on getting the plugin updated.', 'Sorry, but you do not have the correct permissions to update the %s plugins. Contact the administrator of this site for help on getting the plugins updated.' ), // %1$s = plugin name(s)
            'install_link'                              => _n_noop( 'Begin installing plugin', 'Begin installing plugins' ),
            'activate_link'                             => _n_noop( 'Activate installed plugin', 'Activate installed plugins' ),
            'return'                                    => __( 'Return to Required Plugins Installer', $theme_text_domain ),
            'plugin_activated'                          => __( 'Plugin activated successfully.', $theme_text_domain ),
            'complete'                                  => __( 'All plugins installed and activated successfully. %s', $theme_text_domain ) // %1$s = dashboard link
        )
    );

    tgmpa( $plugins, $config );

}
/* TGM Plugin Activation end */



/**
 * Register widget area.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_sidebar
 */
function privado_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Blog Sidebar', 'privado' ),
		'id'            => 'sidebar-1',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
	) );
}
add_action( 'widgets_init', 'privado_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function privado_scripts() {

	wp_enqueue_style( 'privado-style', get_stylesheet_uri() );
    wp_enqueue_script("jquery");
	wp_enqueue_script( 'privado-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20120206', true );
	wp_enqueue_script( 'privado-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20130115', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

    wp_enqueue_style("privado-bs",get_template_directory_uri()."/css/bootstrap.min.css");
    wp_enqueue_style("privado-owl",get_template_directory_uri()."/css/owl.carousel.css");
    wp_enqueue_style("privado-owl-theme",get_template_directory_uri()."/css/owl.theme.css");
    wp_enqueue_style("privado-mfp",get_template_directory_uri()."/css/magnific-popup.css");
    wp_enqueue_style("privado-google-os","//fonts.googleapis.com/css?family=PT+Sans:400,700|Merriweather:400italic,400");
    wp_enqueue_style("privado-fa",get_template_directory_uri()."/fonts/font-awesome-4.3.0/css/font-awesome.min.css");
    wp_enqueue_style("privado-css",get_template_directory_uri()."/css/style.css");
    wp_enqueue_style("privado-responsive",get_template_directory_uri()."/css/responsive.css");

    // Dynamic CSS
	wp_enqueue_style('dynamic-css',
	                 admin_url('admin-ajax.php').'?action=dynamic_css');

    wp_enqueue_script( 'privado-modernizr', get_template_directory_uri() . '/js/modernizr.js', array("jquery"), '1.0', false );
    wp_enqueue_script( 'privado-bs', get_template_directory_uri() . '/js/bootstrap.min.js', array("jquery"), '1.0', true );
    wp_enqueue_script( 'privado-googleapis', '//maps.googleapis.com/maps/api/js?v=3.exp&AMP;sensor=false', array("jquery"), '1.0', true );    
    wp_enqueue_script('privado-gmaps', get_template_directory_uri() . '/js/gmaps.js', array("privado-googleapis"), '1.0', true);
    wp_enqueue_script( 'privado-owl', get_template_directory_uri() . '/js/owl.carousel.min.js', array("jquery"), '1.0', true );
    wp_enqueue_script( 'privado-mfp', get_template_directory_uri() . '/js/jquery.magnific-popup.js', array("jquery"), '1.0', true );
    wp_enqueue_script( 'privado-mixitup', get_template_directory_uri() . '/js/jquery.mixitup.js', array("jquery"), '1.0', true );
    wp_enqueue_script( 'privado-charts', get_template_directory_uri() . '/js/jquery.easy-pie-chart.js', array("jquery"), '1.0', true ); 
    wp_enqueue_script('privado-js', get_template_directory_uri() . '/js/scripts.js', array("jquery", "privado-googleapis", "privado-gmaps"), '1.0', true);
    wp_localize_script("privado-js","site",array("url"=>site_url("/"),"theme_path"=>get_template_directory_uri()));
    

}
add_action( 'wp_enqueue_scripts', 'privado_scripts' );

// Dynamic CSS

function privado_dynamic_css() {
       require(get_template_directory().'/css/dynamic.css.php');
       exit;
}

add_action('wp_ajax_dynamic_css', 'privado_dynamic_css');
add_action('wp_ajax_nopriv_dynamic_css', 'privado_dynamic_css');

/**
 * Implement the Custom Header feature.
 */
//require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

/**
* Modify the footer credits for JetPack Inifite Scroll
**/
add_filter('infinite_scroll_credit','lc_infinite_scroll_credit');
	function lc_infinite_scroll_credit(){
	$content =  $codetic_privado['privado_footer'];
return $content;
}

/** End JetPack **/ 


/**
 * Load Metaboxes
 */

require get_template_directory() . '/inc/metaboxes/mb-services.php';
require get_template_directory() . '/inc/metaboxes/mb-testimonials.php';
require get_template_directory() . '/inc/metaboxes/mb-education.php';
require get_template_directory() . '/inc/metaboxes/mb-employment.php';
require get_template_directory() . '/inc/metaboxes/mb-recognition.php';


/**
 * Process Social Links
 */

function privado_social_links()
{
    global $codetic_privado;


    $privado_facebook_data = ( isset($codetic_privado['privado_social_facebook']) ) ? trim( $codetic_privado['privado_social_facebook'] ) : "";
    $privado_twitter_data = ( isset($codetic_privado['privado_social_twitter']) ) ? trim( $codetic_privado['privado_social_twitter'] ) : "";
    $privado_gplus_data = ( isset($codetic_privado['privado_social_gplus']) ) ? trim( $codetic_privado['privado_social_gplus'] ) : "";
    $privado_linkedin_data = ( isset($codetic_privado['privado_social_linkedin']) ) ? trim( $codetic_privado['privado_social_linkedin'] ) : "";
    $privado_github_data = ( isset($codetic_privado['privado_social_github']) ) ? trim( $codetic_privado['privado_social_github'] ) : "";
    $privado_dribbble_data = ( isset($codetic_privado['privado_social_dribbble']) ) ? trim( $codetic_privado['privado_social_dribbble'] ) : "";
    $privado_slideshare_data = ( isset($codetic_privado['privado_social_slideshare']) ) ? trim( $codetic_privado['privado_social_slideshare'] ) : "";
    $privado_instagram_data = ( isset($codetic_privado['privado_social_instagram']) ) ? trim( $codetic_privado['privado_social_instagram'] ) : "";
    $privado_skype_data = ( isset($codetic_privado['privado_social_skype']) ) ? trim( $codetic_privado['privado_social_skype'] ) : "";

    $privado_social_links = array(
        'facebook'  => array(
            'data' => $privado_facebook_data,
            'icon' => 'fa-facebook'
        ),
        'twitter'   => array(
            'data' => $privado_twitter_data,
            'icon' => 'fa-twitter'
        ),
        'gplus'    => array(
            'data' => $privado_gplus_data,
            'icon' => 'fa-google-plus'
        ),
        'linkedin'  => array(
            'data' => $privado_linkedin_data,
            'icon' => 'fa-linkedin'
        ),
        'github' => array(
            'data' => $privado_github_data,
            'icon' => 'fa-github'
        ),
        'dribbble'  => array(
            'data' => $privado_dribbble_data,
            'icon' => 'fa-dribbble'
        ),
        'slideshare' => array(
            'data' => $privado_slideshare_data,
            'icon' => 'fa-slideshare'
        ),
        'instagram' => array(
            'data' => $privado_instagram_data,
            'icon' => 'fa-instagram'
        ),
        'skype' => array(
            'data' => $privado_skype_data,
            'icon' => 'fa-skype'
        )
    );

    $privado_htmlLinks = "";

    foreach ($privado_social_links as $privado_social_name => $privado_social_link) {
        if ( !empty($privado_social_link['data']) ) {
            if ( $privado_social_name == 'skype' ) {
                $privado_htmlLinks.= "<li><a href='callto:{$privado_social_link['data']}'><i class='fa {$privado_social_link['icon']}'></i></a></li>";
            } else {

                $privado_htmlLinks.= "<li><a href='{$privado_social_link['data']}' target='_blank'><i class='fa {$privado_social_link['icon']}'></i></a></li>";
            }
        }
    }

    return $privado_htmlLinks;
}

