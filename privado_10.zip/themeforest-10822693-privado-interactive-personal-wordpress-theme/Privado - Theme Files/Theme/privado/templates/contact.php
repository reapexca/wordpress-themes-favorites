<?php

get_template_part("templates/sections/contact-header");
get_template_part("templates/sections/send-message");
get_template_part("templates/sections/address");
get_template_part("templates/sections/footer");