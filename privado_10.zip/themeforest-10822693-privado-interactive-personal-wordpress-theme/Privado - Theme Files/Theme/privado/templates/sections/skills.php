<?php
global $codetic_privado;
if($codetic_privado['privado_skills_section_display']){
?>
<section class="row skills">
    <div class="over-div"></div>
    <div class="sec-divider"></div>
    <h2 class="section-title"><?php echo esc_html($codetic_privado['privado_skills_title']);?></h2>

        <div class='skill-container container'>
            <div class='row'>

        <?php
            if( $codetic_privado['privado_skills'] ) {
                $skills = $codetic_privado['privado_skills'];

                foreach ($skills as $skill) {
                    $skill_arg = explode(',', trim($skill));

                    echo "<div class='col-xs-6 col-sm-6 col-md-3 skill'>";
                        echo "<figure class='chart' data-percent='$skill_arg[1]'>
                           <figcaption>$skill_arg[0]</figcaption>
                        </figure>";
                    echo "</div>";
                }
            }
        ?>

            </div> <!-- row end--> 
        </div> <!-- Skill container -->
</section>
<!-- Skills Section end -->
<?php } ?>