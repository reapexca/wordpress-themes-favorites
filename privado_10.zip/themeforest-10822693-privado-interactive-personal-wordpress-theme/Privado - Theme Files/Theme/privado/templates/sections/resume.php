<?php
global $codetic_privado;
if($codetic_privado['privado_resume_section_display']){
?>


<!-- Resume section-->
<section class="row resume">
    <div class="over-div"></div>
    <div class="container">

        <!-- Education Section --> 

        <?php $limit = $codetic_privado['education_post_number']; $order = get_order_value($codetic_privado['education_post_order']); $educations = privado_get_custom_posts('education', $limit, $order); ?>

        <div class="col-xs-6 education">
            <h2><?php echo esc_html($codetic_privado['privado_education_title']);?></h2>

        <?php if ( $educations ) : ?>
            <ul class="edu-list">
            <?php foreach ($educations as $education) : $education_meta = get_post_meta($education->ID); ?>
                <li>
                    <h3><?php echo $education_meta['_privado_edu_college'][0]; ?></h3>
                    <h4><?php echo $education_meta['_privado_edu_degree'][0]; ?></h4>
                    <span><?php echo $education_meta['_privado_edu_time'][0]; ?></span>
                    <p><?php echo $education_meta['_privado_edu_description'][0]; ?></p>
                </li>
            <?php endforeach; ?>
            </ul>
        <?php endif; ?>
        </div> <!-- educations end -->
    

        <!-- Employment Section -->

        <?php $limit = $codetic_privado['employment_post_number']; $order = get_order_value($codetic_privado['employment_post_order']); $employments = privado_get_custom_posts('employment', $limit, $order); ?>

        <div class="col-xs-6 employment">
            <h2><?php echo esc_html($codetic_privado['privado_employment_title']);?></h2>

        <?php if ( $employments ) : ?>
            <ul class="employment-list">
            <?php foreach ($employments as $employment) : $employment_meta = get_post_meta($employment->ID); ?>
                <li>
                    <h3><?php echo $employment_meta['_privado_employment_company'][0]; ?></h3>
                    <h4><?php echo $employment_meta['_privado_employment_designation'][0]; ?></h4>
                    <span><?php echo $employment_meta['_privado_employment_time'][0]; ?></span>
                    <p><?php echo $employment_meta['_privado_employment_description'][0]; ?></p>
                </li>
            <?php endforeach; ?>
            </ul>
        <?php endif; ?>
        </div> <!-- employments end -->
    </div> <!-- .container-->
</section>
<!-- Resume section end -->
<?php } ?>