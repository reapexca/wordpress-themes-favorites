<?php
global $codetic_privado;
?>
<section class="row contact">
<div class="over-div"></div>
<div class="sec-divider"></div>
<h2 class="section-title"><?php echo esc_html($codetic_privado['privado_contact_form_title']);?></h2>

<!-- form -->
<section class="row"> 
    <div class="col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3 form-container">

         <!-- Contact Form End -->
        <?php if (isset( $codetic_privado['privado_contact_form_shortcode'] )) {
            echo do_shortcode($codetic_privado['privado_contact_form_shortcode']);
        } ?>
        <!-- Contact Form End -->

    </div>
</section>
<!-- Form Container End -->