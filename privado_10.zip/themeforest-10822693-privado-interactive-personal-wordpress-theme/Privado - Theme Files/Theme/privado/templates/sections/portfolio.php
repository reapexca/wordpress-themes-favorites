<?php
global $codetic_privado;
if($codetic_privado['privado_portfolio_section_display']){
?>

<section class="row portfolios">
    <div class="portfolio-container">

    <!-- Filter buttons -->

        <!-- Filters -->
        <?php if(!is_tax()) {
            $terms = get_terms("filters");
            $count = count($terms);
            if ( $count > 0 ){ ?>
                <div class="controls">
                    <button class="filter" data-filter="all"><?php  _e('All', 'privado'); ?></button>
            <?php
                foreach ( $terms as $term ) {
                    echo '<button class="filter" data-filter=".'.$term->slug.'">'. $term->name .'</button> ';
                } ?>

                </div><!-- Filter buttons end-->
        <?php } } ?>


    <div id="portfolio" class="portfolio-items fig-effects">

        <?php

        $limit = $codetic_privado['portfolio_number']; 
        $order = get_order_value($codetic_privado['portfolio_post_order']);

        // Portfolio Query arguments
        $args = array (
            'posts_per_page'         => $limit,
            'order'                  => $order,
            'post_type' => 'portfolio',
        );

        // TPortfolio Query
        $query = query_posts( $args );

            if( have_posts() ):
                while( have_posts() ): the_post();
        ?>

        <div <?php post_class ('col-sm-6 col-md-4 mix'); ?>>
            <figure class="effect-roxy">
                <?php if( has_post_thumbnail() ): ?>
                    <?php the_post_thumbnail( 'portfolio-thumb' ) ?>
                <?php endif; ?>

            <figcaption>
                <h2><?php the_title(); ?></h2>
                <p><?php
                    $content = get_the_content();
                    $trimmed_content = wp_trim_words( $content, 10, null );
                    echo $trimmed_content;
                    ?>
                </p>
                <a href="#portfolio-<?php the_ID(); ?>" class="open-portfolio" >Explore</a>
            </figcaption>

            </figure>
        </div>

        <!--Single portfolio item -->

        <!-- Popup content -->
        <div id="portfolio-<?php echo the_ID(); ?>" class="white-popup mfp-hide">
            <?php if( has_post_thumbnail() ): ?>
                <?php the_post_thumbnail( 'portfolio-preview' ) ?>
            <?php endif; ?>
        <!-- project Description -->
        <div class="project-desc">
            <?php echo the_content();?>
        </div>


        </div> <!-- Popup content end -->
        <!--.Single item end-->

        <?php
                endwhile;
            endif;
            wp_reset_query();
        ?>


    </div> <!-- #portfolio end-->

    </div>
    <!-- .portfolio-container -->
</section>
<!-- portfolio section end-->
<?php } ?>