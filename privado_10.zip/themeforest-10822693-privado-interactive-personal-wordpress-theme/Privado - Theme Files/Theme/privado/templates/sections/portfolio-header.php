<?php
global $codetic_privado;
?>
<!-- Portfolio Page -->

<section class="single-page is-loaded">
    <header class="page-title">
        <span><i class="fa fa-3x <?php echo esc_attr($codetic_privado['privado_portfolio_page_icon']);?>"></i></span>
        <h2><?php echo esc_html($codetic_privado['privado_portfolio_page_title']);?></h2>
        <p class="menu-desc"><?php echo esc_html($codetic_privado['privado_portfolio_page_subtitle']);?></p>
    </header>
    <!-- .page-title -->

<!-- Portfolio Page Contents-->
    <article class="page-info container-fluid">