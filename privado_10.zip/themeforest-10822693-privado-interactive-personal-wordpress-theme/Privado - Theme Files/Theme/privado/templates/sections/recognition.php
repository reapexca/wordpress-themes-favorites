<?php
global $codetic_privado;
if($codetic_privado['privado_skills_section_display']){
?>

<?php $limit = $codetic_privado['recognition_post_number']; $order = get_order_value($codetic_privado['recognition_post_order']); $recognitions = privado_get_custom_posts('recognition', $limit, $order); ?>

<section class="row recognition">
    <div class="col-sm-6 rec-desc">
        <div class="rec-inner">
            <h2><?php echo esc_html($codetic_privado['privado_recognition_title']);?></h2>
            <?php echo wpautop($codetic_privado['privado_recognition_description']);?>
        </div>
    </div>

    <div class="col-sm-6 rec-list">
<?php if ( $recognitions ) : ?>
        <ul>
        <?php foreach ($recognitions as $recognition) : $recognition_meta = get_post_meta($recognition->ID); ?>
            <li>
                <span class="fa fa-5x pull-left fa-fw <?php echo $recognition_meta['_privado_recognition_icon'][0]; ?>"></span>
                <h3><?php echo $recognition_meta['_privado_recognition_title'][0]; ?></h3>
                <h5><?php echo $recognition_meta['_privado_recognition_subtitle'][0]; ?></h5>
                <h4><?php echo $recognition_meta['_privado_recognition_place'][0]; ?></h4>
            </li>
        <?php endforeach; ?>
        </ul>
<?php endif; ?>
    </div>

</section>
<!-- Recognition section end -->
<?php } ?>