<?php

get_template_part("templates/sections/portfolio-header");
get_template_part("templates/sections/portfolio");
get_template_part("templates/sections/testimonials");
get_template_part("templates/sections/footer");