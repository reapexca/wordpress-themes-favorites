<?php

get_template_part("templates/sections/resume-header");
get_template_part("templates/sections/resume");
get_template_part("templates/sections/skills");
get_template_part("templates/sections/recognition");
get_template_part("templates/sections/footer");