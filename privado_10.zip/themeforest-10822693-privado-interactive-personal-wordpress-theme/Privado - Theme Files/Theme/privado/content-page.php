<?php
/**
 * The template used for displaying page content in page.php
 *
 * @package Privado
 */
$home_url = site_url();
$thumbnail = '';
	if (function_exists('has_post_thumbnail')) {
	    if ( has_post_thumbnail() ) {
	         $thumbnail = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
	    }
	}

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="single-page-header" style="background: url('<?php echo $thumbnail; ?>') no-repeat fixed center center / cover;">
        <div class="header-inner">
            <a href="<?php echo $home_url;?>" class="btn back-to-home"><i class="fa fa-home fa-fw"></i>Home</a>
                <div class="header-content">
                    <?php the_title( '<h1 class="blog-title container">', '</h1>' ); ?>
                </div>
        </div>
    </header>

    <section>
        <div class="container single-page-container">
            <article>
                <div class="post-content">
					<?php the_content(); ?>
					<?php
						wp_link_pages( array(
							'before' => '<div class="page-links">' . __( 'Pages:', 'privado' ),
							'after'  => '</div>',
						) );
					?>
                </div>
            </article>  <!--Single blog-->  
        
        </div><!-- Blog List end -->
    </section>
     <!-- #Blog List end-->

</article><!-- #post-## -->
