<?php
global $codetic_privado;

/**
 * @package Privado
 */

$blog_url = $codetic_privado['privado_blog_url'];
$thumbnail = '';
	if (function_exists('has_post_thumbnail')) {
	    if ( has_post_thumbnail() ) {
	         $thumbnail = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
	    }
	}

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

        <header class="single-blog-header" style="background: url('<?php echo $thumbnail; ?>') no-repeat fixed center center / cover;">
            <div class="header-inner">
                <a href="<?php echo esc_url($blog_url);?>" class="btn back-to-home"><i class="fa fa-arrow-left fa-fw"></i>Back to Blog</a>
                    <div class="header-content">
                        <?php the_title( '<h1 class="blog-title container">', '</h1>' ); ?>
                        <div class="blog-author">
                            <div class="media author-avatar">
                                    <?php echo get_avatar( get_the_author_meta( 'ID' ), 96 ); ?> 
                                <div class="media-body">
                                    <h4 class="media-heading"><?php the_author(); ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        </header>

        <div class="single-blog-meta">
            <div class="col-sm-4 meta-date">
                <time><i class="fa fa-clock-o fa-fw"></i><?php the_time( get_option( 'date_format' ) ); ?></time>
            </div>
            <div class="col-sm-4 meta-comments">
                <span><i class="fa fa-comments fa-fw"></i><a class="scroll-to-comments" href="#comments"><?php comments_number( 'No Responses', '1 Comment', '% Comments' ); ?></a></span>
            </div>
            <div class="col-sm-4 meta-cat">
                <span><i class="fa fa-tag fa-fw"></i> 
                    <?php
                        $categories = get_the_category();
                        $separator = ', ';
                        $output = '';
                        if($categories){
                            foreach($categories as $category) {
                                $output .= '<a href="'.get_category_link( $category->term_id ).'" title="' . esc_attr( sprintf( __( 'View all posts in %s', 'privado' ), $category->name ) ) . '">'.$category->cat_name.'</a>'.$separator;
                            }
                        echo trim($output, $separator);
                        }
                        ?>
                </span>
            </div>
        </div>

        <section>
            <div class="container single-blog-container">
                <article>
                    <div class="post-content">
						<?php the_content(); ?>
					
					</div><!-- Post Content-->

					<div class="col-md-12 post-tags">
						 <?php the_tags( '<ul><li>', '</li><li>', '</li></ul>' ); ?>
					</div> <!-- Post Tags end -->

                    <div class="col-md-12 post-author">
                        <div class="panel-body ">
                            <div class="media author-avatar">
                                <div class="pull-left avatar-container">
                                    <?php echo get_avatar( get_the_author_meta( 'ID' ), 96 ); ?> 
                                </div>

                                <div class="media-body">
                                    <span>Author</span>
                                    <h4 class="media-heading">
                                         <?php the_author_posts_link(); ?> 
                                    </h4>
                                    <h5><?php the_author_meta('description'); ?></h5>
                                </div>
                            </div>
                        </div>
                    </div> <!-- Author end -->

                    <div class="col-sm-12 col-md-12 social-share">
                    	<div class="col-sm-12 col-md-3">
                    		<h5>Share This Story</h5>
                    	</div>
                    	<div class="col-sm-12 col-md-9">
                    		<ul class="social-share-links">
                    			<li><a href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" target="_blank"><i class="fa fa-2x fa-fw fa-facebook"></i></a></li>

                    			<li><a href="https://twitter.com/home?status=<?php the_permalink(); ?>" target="_blank"><i class="fa fa-2x fa-fw fa-twitter"></i></a></li>

                    			<li><a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>&title=&summary=&source=" target="_blank"><i class="fa fa-2x fa-fw fa-linkedin"></i></a></li>

                    			<li><a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" target="_blank"><i class="fa fa-2x fa-fw fa-google-plus"></i></a></li>

                    			<li><a href="https://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&media=<?php echo $thumbnail; ?>&description=" target="_blank"><i class="fa fa-2x fa-fw fa-pinterest"></i></a></li>
                    		</ul>
                    	</div>
                    </div> <!-- Social Share end-->

				</article>  <!--Single blog-->  
            </div><!-- Blog List end -->
        </section>

</article><!-- #post-## -->
