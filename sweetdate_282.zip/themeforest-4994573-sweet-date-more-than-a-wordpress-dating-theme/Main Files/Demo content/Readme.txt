To import our Demo content you should install WordPress Importer plugin

http://wordpress.org/extend/plugins/wordpress-importer/

1 - Download it and upload on your server (wp-content/plugins) or install it from Wordpress Admin -> Plugins

2 - Go to tools - Import

3 - Choose "Wordpress"

4 - Upload "demo-sweetdate.xml" (choose to import images if you want)

5 - Done!
