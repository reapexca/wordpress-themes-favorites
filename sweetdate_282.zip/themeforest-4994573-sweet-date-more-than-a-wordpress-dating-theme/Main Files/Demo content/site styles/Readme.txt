To import the color styles: 
1. Go to WP Admin -> Sweetdate -> Import/Export
2. Click the import from text button
3. Paste the text from one of the style files in this directory
4. Click Import.

Warnig: Your previous theme options set in WP Admin -> Sweetdate will be erased and replaced with this styles.
