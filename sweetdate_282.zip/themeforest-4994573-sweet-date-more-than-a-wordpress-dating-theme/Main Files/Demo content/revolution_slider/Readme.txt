Revolution slider.

We have created some demo sliders so you have a starting point. You can see the sliders in action at our demo site: http://seventhqueen.com/demo/sweetdatewp
To import the slider:
- Go to Wordpress Admin -> Revolution Slider -> Import Slider.
- Browse to the Demo content folder, located in the package downloaded, and go to revolution_slider.
- Choose one of the .zip files located in "exported sliders" folder

You can add revolution slider:
- to Homepage from Sweetdate -> Homepage
- to post/page header section from the page edit -> General settings -> Header settings
- to post/page content using the displayed shortcode

We also included the custom slider bullets and arrows in folder revslider_assets. If you want to use them you have to replace the default ones located in wp-content/plugins/revslider/rs-plugin/assets/

Please see full Revolution Slider documentation http://themepunch.com/codecanyon/revolution_wp/documentation/
