Revolution slider.

We have created some demo sliders so you have a starting point. You can see the sliders in action at our demo site: http://seventhqueen.com/demo/sweetdatewp
To import the slider:
- Go to Wordpress Admin -> Revolution Slider -> Import Slider.
- Browse to the Demo content folder, located in the package downloaded, and go to revolution_slider.
- Choose one of the files and click Import Slider

Revolution slider doesn't import images so we have included some layers we used except for the ones what carry author rights.
You need to Edit slides and upload the images located in images folder. 
After you have uploaded the included images you need to:
- Change the background images with the ones that you just uploaded (profile_users.jpg) and image layers if it is the case.
- Replace captions.css text from a Slide edit page -> Layer General Parameters -> Edit CSS File with the one included in the demo folder

You can add revolution slider:
- to Homepage from Sweetdate -> Homepage
- to post/page header section from the page edit -> General settings -> Header settings
- to post/page content using the displayed shortcode

We also included the custom slider bullets and arrows in folder revslider_assets. If you want to use them you have to replace the default ones located in wp-content/plugins/revslider/rs-plugin/assets/

Please see full Revolution Slider documentation http://themepunch.com/codecanyon/revolution_wp/documentation/
